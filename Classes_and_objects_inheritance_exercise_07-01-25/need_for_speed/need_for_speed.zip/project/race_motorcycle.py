from project.motorcycle import MotorCycle


class RaceMotorCycle(MotorCycle):
    DEFAULT_FUEL_CONSUMPTION = 8