from project.motorcycle import MotorCycle


class CrossMotorCycle(MotorCycle):
    pass