from project.vehicle import Vehicle

class MotorCycle(Vehicle):
    pass